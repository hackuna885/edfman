<html>
	<head>
		<meta http-equiv="REFRESH" content="0; url=../../error/alerta.aspx?error=404">
	</head>
</html>